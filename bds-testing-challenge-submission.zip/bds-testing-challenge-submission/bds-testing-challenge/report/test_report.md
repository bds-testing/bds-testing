# High-level Test Report – BDS Testing Challenge

## 1. Scope
This submission covers:
- **Test #1:** Search API automation (OSDD XML + search JSON extraction)
- **Test #2:** REST API traversal for daily product count and identifiers
- **Test #3:** Backend log parsing to build a per-product timeline across services

No UI automation is included because all requirements are satisfied via API interactions and log analysis.

## 2. Tools
- Python 3
- requests (HTTP), built-in xml/json/csv/logging modules

## 3. Test #1 Results (Search API)
### What was tested
- Retrieved OSDD (XML) for collection `EO:EUM:DAT:METOP:ASCSZF1B` and extracted 5–10 available parameters.
- Executed the provided search query (JSON) and extracted:
  - `properties.identifier`
  - `platformShortName`
  - `instrumentShortName`
  - `orbitNumber`
  - `productType`

### Produced artifacts
- `test1_search_api/output/parameters.json`
- `test1_search_api/output/products.json`

## 4. Test #2 Results (Browse API traversal)
### What was tested
- Navigated browse tree (years → months → days) for collection `EO:EUM:DAT:METOP:SOMO12`
- For **2023-04-12**, collected number of products and their identifiers

### Produced artifacts
- `test2_rest_api/output/products_2023_04_12.csv`

## 5. Test #3 Results (Log parsing)
### What was tested
- Extracted the gateway-generated UUID per product from `olda-ingestion-gateway-normal-0.log`
- Correlated events for each UUID across the 4 service logs and produced a readable timeline grouped by service

### Produced artifacts
- `test3_log_parsing/output/product_events.log`

## 6. How to run
See `README.md`.

## 7. Limitations / Potential improvements
- Add retries/backoff and richer status validation for transient network errors.
- Add optional filtering flags (single product / single UUID) for log parsing output.
- Add unit tests around parsers (XML/JSON/log line timestamp parsing).
