import time
import requests

DEFAULT_TIMEOUT = 20

def http_get(url: str, *, timeout: int = DEFAULT_TIMEOUT, retries: int = 2, backoff_s: float = 1.0, headers=None):
    """Simple GET with retries. Raises requests.HTTPError for non-2xx."""
    last_exc = None
    for attempt in range(retries + 1):
        try:
            resp = requests.get(url, timeout=timeout, headers=headers, verify=False)
            resp.raise_for_status()
            return resp
        except Exception as exc:
            last_exc = exc
            if attempt < retries:
                time.sleep(backoff_s * (attempt + 1))
    raise last_exc
