import argparse
import csv
import urllib.parse

from common.http import http_get

BASE = "https://vapi.eumetsat.int/data/browse/1.0.0/collections/{collection}/dates/"

def url_for(collection: str, suffix: str = ""):
    coll_enc = urllib.parse.quote(collection, safe="")
    return BASE.format(collection=coll_enc) + suffix + "?format=json"

def extract_children(payload):
    if isinstance(payload, list):
        out = []
        for x in payload:
            if isinstance(x, str):
                out.append(x)
            elif isinstance(x, dict):
                for k in ("name", "id", "value", "date"):
                    if k in x:
                        out.append(str(x[k]))
                        break
        return out

    if isinstance(payload, dict):
        for key in ("children", "items", "results", "years", "months", "days"):
            if key in payload and isinstance(payload[key], list):
                return extract_children(payload[key])

    return []

def list_products_for_day(collection: str, year: str, month: str, day: str):
    resp = http_get(url_for(collection, f"{year}/{month}/{day}"))
    payload = resp.json()

    ids = []

    if isinstance(payload, dict) and "features" in payload and isinstance(payload["features"], list):
        for feat in payload["features"]:
            if isinstance(feat, dict):
                props = feat.get("properties", {})
                if isinstance(props, dict) and "identifier" in props:
                    ids.append(str(props["identifier"]))

    if not ids and isinstance(payload, dict):
        for key in ("products", "items", "results"):
            if key in payload and isinstance(payload[key], list):
                for item in payload[key]:
                    if isinstance(item, dict):
                        for k in ("identifier", "id", "name"):
                            if k in item:
                                ids.append(str(item[k]))
                                break

    if not ids:
        ids = extract_children(payload)

    seen=set()
    out=[]
    for x in ids:
        if x not in seen:
            seen.add(x); out.append(x)
    return out

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--collection", required=True, help="e.g. EO:EUM:DAT:METOP:SOMO12")
    ap.add_argument("--date", required=True, help="YYYY-MM-DD (e.g. 2023-04-12)")
    ap.add_argument("--out", required=True, help="Output CSV path")
    args = ap.parse_args()

    year, month, day = args.date.split("-")
    product_ids = list_products_for_day(args.collection, year, month, day)

    with open(args.out, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["date", "product_count", "product_identifiers"])
        w.writerow([args.date, len(product_ids), ";".join(product_ids)])

    print(f"[OK] {args.date}: {len(product_ids)} products -> {args.out}")

if __name__ == "__main__":
    main()
