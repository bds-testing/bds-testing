import argparse
import json
import re
import xml.etree.ElementTree as ET

from common.http import http_get

OSDD_URL = "https://vapi.eumetsat.int/data/search-products/1.0.0/osdd?pi={pi}"

def extract_parameter_names(xml_text: str):
    """
    OSDD is XML. Parameters often appear as:
      <param:Parameter name="dtstart" ... />
    XML namespaces vary, so we search for any element with attribute 'name'.
    """
    root = ET.fromstring(xml_text)

    names = []
    for elem in root.iter():
        name = elem.attrib.get("name")
        if name and name not in names:
            names.append(name)

    # Fallback regex (tolerant) if parsing yields few names
    if len(names) < 5:
        for m in re.findall(r'name="([^"]+)"', xml_text):
            if m not in names:
                names.append(m)

    return names

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pi", required=True, help="Collection ID (pi), e.g. EO:EUM:DAT:METOP:ASCSZF1B")
    ap.add_argument("--out", required=True, help="Output JSON file path")
    ap.add_argument("--limit", type=int, default=10, help="How many parameter names to write (default: 10)")
    args = ap.parse_args()

    url = OSDD_URL.format(pi=args.pi)
    resp = http_get(url)
    names = extract_parameter_names(resp.text)[:args.limit]

    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(names, f, indent=2)

    print(f"[OK] Extracted {len(names)} parameter names -> {args.out}")

if __name__ == "__main__":
    main()
