import argparse
import json

from common.http import http_get

SEARCH_URL = (
    "https://vapi.eumetsat.int/data/search-products/1.0.0/os"
    "?format=json&pi={pi}&dtstart={dtstart}&dtend={dtend}"
)

FIELDS = [
    ("identifier", ("properties", "identifier")),
    ("platformShortName", ("properties", "platformShortName")),
    ("instrumentShortName", ("properties", "instrumentShortName")),
    ("orbitNumber", ("properties", "orbitNumber")),
    ("productType", ("properties", "productType")),
]

def safe_get(dct, path, default=None):
    cur = dct
    for p in path:
        if isinstance(cur, dict) and p in cur:
            cur = cur[p]
        else:
            return default
    return cur

def parse_products(payload):
    """
    Tolerant parser. Common shape is GeoJSON-like:
      { "features": [ { "properties": {...} }, ... ] }
    """
    candidates = None
    if isinstance(payload, dict):
        for key in ("features", "items", "products", "results"):
            if key in payload and isinstance(payload[key], list):
                candidates = payload[key]
                break
    if candidates is None:
        return []

    rows = []
    for item in candidates:
        row = {}
        for out_key, path in FIELDS:
            row[out_key] = safe_get(item, path, default=None)
        rows.append(row)
    return rows

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pi", required=True)
    ap.add_argument("--dtstart", required=True)
    ap.add_argument("--dtend", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    url = SEARCH_URL.format(pi=args.pi, dtstart=args.dtstart, dtend=args.dtend)
    resp = http_get(url)
    payload = resp.json()

    rows = parse_products(payload)

    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(rows, f, indent=2)

    print(f"[OK] Extracted {len(rows)} products -> {args.out}")

if __name__ == "__main__":
    main()
