import argparse
import os
import re
import zipfile
from datetime import datetime

UUID_RE = re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", re.I)
ZIP_NAME_RE = re.compile(r"([A-Za-z0-9_.-]+\.zip)")

SERVICE_ORDER = [
    "olda-ingestion-gateway-normal-0",
    "olda-ingestion-processing-normal-0",
    "olda-storage-manager-normal-65b44774cc-szgsn",
    "olda-ingestion-housekeeping-normal-57cf8dd646-kh824",
]

def parse_timestamp(line: str):
    m = re.match(r"^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3})", line)
    if m:
        return datetime.strptime(m.group(1), "%Y-%m-%d %H:%M:%S.%f")
    m = re.match(r"^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}),(\d{3})Z", line)
    if m:
        base = datetime.strptime(m.group(1), "%Y-%m-%dT%H:%M:%S")
        return base.replace(microsecond=int(m.group(2)) * 1000)
    return None

def read_lines_from_zip(zip_path: str):
    with zipfile.ZipFile(zip_path) as z:
        for name in z.namelist():
            with z.open(name) as f:
                for raw in f:
                    yield name, raw.decode("utf-8", errors="ignore").rstrip("\n")

def map_product_to_uuid(zip_path: str):
    mapping = {}
    for fname, line in read_lines_from_zip(zip_path):
        if "olda-ingestion-gateway-normal-0.log" not in fname:
            continue
        u = UUID_RE.search(line)
        if not u or ".zip" not in line:
            continue
        pm = ZIP_NAME_RE.search(line)
        if not pm:
            continue
        mapping[pm.group(1)] = u.group(0).lower()
    return mapping

def collect_events_for_uuid(zip_path: str, uuid: str):
    events = []
    for fname, line in read_lines_from_zip(zip_path):
        if uuid not in line.lower():
            continue
        service = os.path.basename(fname).replace(".log", "")
        ts = parse_timestamp(line)
        events.append((ts, service, line))

    def key(x):
        ts = x[0]
        return (ts is None, ts or datetime.min, SERVICE_ORDER.index(x[1]) if x[1] in SERVICE_ORDER else 999)

    events.sort(key=key)
    return events

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--zip", required=True, help="Path to logs.zip")
    ap.add_argument("--out", required=True, help="Output log file path")
    ap.add_argument("--product", default=None, help="Optional: parse only one product filename (exact match)")
    args = ap.parse_args()

    prod_to_uuid = map_product_to_uuid(args.zip)
    if args.product:
        if args.product not in prod_to_uuid:
            raise SystemExit(f"Product not found in gateway log: {args.product}")
        prod_to_uuid = {args.product: prod_to_uuid[args.product]}

    with open(args.out, "w", encoding="utf-8") as out:
        for product, uuid in prod_to_uuid.items():
            out.write(f"Product: {product}\n")
            out.write(f"UUID: {uuid}\n\n")

            events = collect_events_for_uuid(args.zip, uuid)

            by_service = {}
            for ts, service, line in events:
                by_service.setdefault(service, []).append((ts, line))

            for service in SERVICE_ORDER:
                if service not in by_service:
                    continue
                out.write(f"[{service}]\n")
                for ts, line in by_service[service]:
                    ts_s = ts.isoformat(sep=" ") if ts else "UNKNOWN_TS"
                    out.write(f"{ts_s} | {line}\n")
                out.write("\n")

            out.write("="*80 + "\n\n")

    print(f"[OK] Wrote timelines for {len(prod_to_uuid)} products -> {args.out}")

if __name__ == "__main__":
    main()
